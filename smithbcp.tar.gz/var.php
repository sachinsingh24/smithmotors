<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="description" content="Smith Motors is a next-gen mobility company, with technology at its roots.
    Smith Motors is heralding a new generation of top quality high performance Electric mobility equipments.">
    <meta name="keywords" content="Variants, smith motors, electric trolley, electric equpment, electric vehical, electric">
    <meta name="author" content="Augen">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
    <title>Smith Motors | Variants</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/bootstrap-selector/css/bootstrap-select.min.css">
    <!--icon font css-->
    <link rel="stylesheet" href="vendors/themify-icon/themify-icons.css">
    <link rel="stylesheet" href="vendors/flaticon/flaticon.css">
    <link rel="stylesheet" href="vendors/animation/animate.css">
    <link rel="stylesheet" href="vendors/owl-carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="vendors/nice-select/nice-select.css">
    <link rel="stylesheet" href="vendors/elagent/style.css">
    <link rel="stylesheet" href="vendors/magnify-pop/magnific-popup.css">
    <link rel="stylesheet" href="vendors/scroll/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>

<body>
    <?php include 'head.php';?>
    <section class="breadcrumb_area">
        <img class="breadcrumb_shap" src="img/breadcrumb/banner_bg.png" alt="">
        <div class="container">
            <div class="breadcrumb_content text-center">
              <div class="breadcrumb_content text-center">
                  <h1 class="f_p f_700 f_size_50 w_color l_height50 mb_20">Customizable Variations</h1>
                  <p class="f_400 w_color f_size_16 l_height26">Each product has been crafted keeping in mind the Industry requirement<br> every model can be customised to fit your requirement</p>
            </div>
        </div>
    </section>
    <section class="faq_area bg_color sec_pad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 pr_50">
                    <div class="faq_tab">
                        <h4 class="f_p t_color3 f_600 f_size_22 mb_40">Quick Navigation</h4>
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="purchas-tab" data-toggle="tab" href="#purchas" role="tab" aria-controls="purchas" aria-selected="true">Trolley(TR1)</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="returns-tab" data-toggle="tab" href="#returns" role="tab" aria-controls="returns" aria-selected="false">Trolley(TR2)</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="price-tab" data-toggle="tab" href="#price" role="tab" aria-controls="price" aria-selected="false">Trolley(Lift Attachment)</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="care-tab" data-toggle="tab" href="#care" role="tab" aria-controls="care" aria-selected="false">Tipper</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="special-tab" data-toggle="tab" href="#special" role="tab" aria-controls="special" aria-selected="false">Custom</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="tab-content faq_content Cus_acc" id="myTabContent">
                        <div class="tab-pane fade show active" id="purchas" role="tabpanel" aria-labelledby="purchas-tab">

                            <div id="accordion">
                              <div class="col-lg-12">
                                  <div class="product_slider">
                                      <div class="pr_image owl-carousel">
                                          <div class="item">
                                              <img src="img/reso/var1.png" alt="Trolley TR1">
                                          </div>
                                          <div class="item">
                                              <img src="img/reso/var12.png" alt="Trolley TR1">
                                          </div>
                                          <div class="item">
                                              <img src="img/reso/var13.png" alt="Trolley TR1">
                                          </div>
                                      </div>
                                  </div>
                              </div>
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="mb-0">
                                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Exterior Features<i class="ti-plus"></i><i class="ti-minus"></i>
                                        </button>
                                        </h5>
                                    </div>

                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                        <div class="card-body">
                                          <B>Plate Size </B> &nbsp; 1600mm x 1000mm<BR>
                                          <B>Usable plate size </B> &nbsp; 1400mm x 1000mm<BR>
                                          <B>Plate height </B> &nbsp; 350mm<BR>
                                          <B>Frame construction </B> &nbsp; Steel<BR>
                                          <B>Overall dimension (LxWxH) </B> &nbsp; 1750x1000x1100<BR>
                                          <B>Trolley top </B> &nbsp; S S / PP / MS / Rubber<BR>
                                          <B>Color </B> &nbsp; Siemens Grey (customizable)<BR>
                                          <B>Wheel diameter </B> &nbsp; 300mm<BR>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            Performance Stats<i class="ti-plus"></i><i class="ti-minus"></i>
                                    </button>
                                        </h5>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                        <div class="card-body">
                                          <B>Loading capacity </B> &nbsp; 500kg<BR>
                                          <B>Nett weight </B> &nbsp; 140kg<BR>
                                          <B>Turning radius </B> &nbsp; 1.2mt<BR>
                                          <B>Top speed </B> &nbsp; 10km/hr<BR>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingThree">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                Battery Standards <i class="ti-plus"></i><i class="ti-minus"></i>
                                            </button>
                                        </h5>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                        <div class="card-body">
                                          <B>Motor BLDC </B> &nbsp; 900w<BR>
                                          <B>Battery </B> &nbsp; 4 x 12V, 42Ah<BR>
                                          <B>Charger </B> &nbsp; External<BR>
                                          <B>Rapid charging time </B> &nbsp; 3Hrs<BR>
                                          <B>Working time </B> &nbsp; 10Hrs<BR>
                                          <B>Warranty </B> &nbsp; 12months<BR>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingfour">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                              Common Features <i class="ti-plus"></i><i class="ti-minus"></i>
                                            </button>
                                        </h5>
                                    </div>
                                    <div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordion">
                                        <div class="card-body">
                                          <B>The handle includes Fwd / Rev Buttons</B><BR>
                                          <B>Multispeed Selection Switch</B><BR>
                                          <B>Emergency Button</B><BR>
                                          <B>Battery Level Indicator</B><BR>
                                          <B>Least Maintenance</B><BR>
                                          <B>Less Operating Cost</B><BR>
                                          <B>4 Speed Operation</B><BR>
                                          <B>Noiseless</B><BR>
                                          <B>Zero Emissions</B><BR>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="tab-pane fade" id="returns" role="tabpanel" aria-labelledby="returns-tab">
                            <div id="accordion3">
                              <div class="col-lg-12">
                                  <div class="product_slider">
                                      <div class="pr_image owl-carousel">
                                          <div class="item">
                                              <img src="img/reso/var2.png" alt="Trolley TR2">
                                          </div>
                                          <div class="item">
                                              <img src="img/reso/var21.png" alt="Trolley TR2">
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingOne">
                                      <h5 class="mb-0">
                                      <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                      Exterior Features<i class="ti-plus"></i><i class="ti-minus"></i>
                                      </button>
                                      </h5>
                                  </div>

                                  <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Plate Size </B> &nbsp; 1600mm x 1000mm<BR>
                                        <B>Usable plate size </B> &nbsp; 1400mm x 1000mm<BR>
                                        <B>Plate height </B> &nbsp; 350mm<BR>
                                        <B>Frame construction </B> &nbsp; Steel<BR>
                                        <B>Overall dimension (LxWxH) </B> &nbsp; 1750x1000x1100<BR>
                                        <B>Trolley top </B> &nbsp; S S / PP / MS / Rubber<BR>
                                        <B>Color </B> &nbsp; Siemens Grey (customizable)<BR>
                                        <B>Wheel diameter </B> &nbsp; 300mm<BR>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingTwo">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                          Performance Stats<i class="ti-plus"></i><i class="ti-minus"></i>
                                  </button>
                                      </h5>
                                  </div>
                                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Loading capacity </B> &nbsp; 750kg<BR>
                                        <B>Nett weight </B> &nbsp; 155kg<BR>
                                        <B>Turning radius </B> &nbsp; 1.2mt<BR>
                                        <B>Top speed </B> &nbsp; 10km/hr<BR>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingThree">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                              Battery Standards <i class="ti-plus"></i><i class="ti-minus"></i>
                                          </button>
                                      </h5>
                                  </div>
                                  <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Motor BLDC </B> &nbsp; 900w<BR>
                                        <B>Battery </B> &nbsp; 4 x 12V, 42Ah<BR>
                                        <B>Charger </B> &nbsp; External<BR>
                                        <B>Rapid charging time </B> &nbsp; 3Hrs<BR>
                                        <B>Working time </B> &nbsp; 10Hrs<BR>
                                        <B>Warranty </B> &nbsp; 12months<BR>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingfour">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                            Common Features <i class="ti-plus"></i><i class="ti-minus"></i>
                                          </button>
                                      </h5>
                                  </div>
                                  <div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>The handle includes Fwd / Rev Buttons</B><BR>
                                        <B>Multispeed Selection Switch</B><BR>
                                        <B>Emergency Button</B><BR>
                                        <B>Battery Level Indicator</B><BR>
                                        <B>Least Maintenance</B><BR>
                                        <B>Less Operating Cost</B><BR>
                                        <B>4 Speed Operation</B><BR>
                                        <B>Noiseless</B><BR>
                                        <B>Zero Emissions</B><BR>
                                      </div>
                                  </div>
                              </div>
                          </div>
                        </div>

                        <div class="tab-pane fade" id="price" role="tabpanel" aria-labelledby="price-tab">
                            <div id="accordion4">
                              <div class="col-lg-12">
                                  <div class="product_slider">
                                      <div class="pr_image owl-carousel">
                                          <div class="item">
                                              <img src="img/reso/var3.png" alt="Trolley(Lift Attachment)">
                                          </div>
                                          <div class="item">
                                              <img src="img/reso/var32.png" alt="Trolley(Lift Attachment)">
                                          </div>
                                          <div class="item">
                                              <img src="img/reso/var33.png" alt="Trolley(Lift Attachment)">
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingOne">
                                      <h5 class="mb-0">
                                      <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                      Exterior Features<i class="ti-plus"></i><i class="ti-minus"></i>
                                      </button>
                                      </h5>
                                  </div>

                                  <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Plate Size </B> &nbsp; 1600mm x 1000mm<BR>
                                        <B>Usable plate size </B> &nbsp; 1400mm x 1000mm<BR>
                                        <B>Plate height </B> &nbsp; 350mm<BR>
                                        <B>Frame construction </B> &nbsp; Steel<BR>
                                        <B>Overall dimension (LxWxH) </B> &nbsp; 1750x1000x1100<BR>
                                        <B>Trolley top </B> &nbsp; S S / PP / MS / Rubber<BR>
                                        <B>Color </B> &nbsp; Siemens Grey (customizable)<BR>
                                        <B>Wheel diameter </B> &nbsp; 300mm<BR>
                                      </div>
                                  </div>
                              </div>

                              <div class="card">
                                  <div class="card-header" id="headingTwo">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                          Lift Attachment Specification <i class="ti-plus"></i><i class="ti-minus"></i>
                                  </button>
                                      </h5>
                                  </div>
                                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                    <div class="card-body">
                                      <B>Rate of lift </B> &nbsp; 1”/ Hand wheel Revolution<BR>
                                      <B>Galvanized steel wire rope </B> &nbsp; 3/8"<BR>
                                      <B>Hand wheel height </B> &nbsp; 1250mm<BR>
                                      <B>Max lift height from floor (in Trolley) </B> &nbsp; 1650mm<BR>
                                      <B>Reach </B> &nbsp; 1000mm<BR>
                                      <B>Outrigger balancing arm (extentable) </B> &nbsp; 350mm to 650mm<BR>
                                      <B>Cable Travel </B> &nbsp; 2.5mt<BR>
                                      <B>Load limit (in Trolley) </B> &nbsp; 250kg<BR>
                                      <B>Welkin lift weight </B> &nbsp; 40kg<BR>
                                      <B>Base weights </B> &nbsp; 18kg<BR>
                                      <B>Pivot rotation </B> &nbsp; 360°<BR>
                                      <B>Overall height from floor </B> &nbsp; 1800mm<BR>
                                    </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingTwo">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                          Performance Stats<i class="ti-plus"></i><i class="ti-minus"></i>
                                  </button>
                                      </h5>
                                  </div>
                                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Loading capacity </B> &nbsp; 500kg<BR>
                                        <B>Nett weight </B> &nbsp; 140kg<BR>
                                        <B>Turning radius </B> &nbsp; 1.2mt<BR>
                                        <B>Top speed </B> &nbsp; 10km/hr<BR>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingThree">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                              Battery Standards <i class="ti-plus"></i><i class="ti-minus"></i>
                                          </button>
                                      </h5>
                                  </div>
                                  <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Motor BLDC </B> &nbsp; 900w<BR>
                                        <B>Battery </B> &nbsp; 4 x 12V, 42Ah<BR>
                                        <B>Charger </B> &nbsp; External<BR>
                                        <B>Rapid charging time </B> &nbsp; 3Hrs<BR>
                                        <B>Working time </B> &nbsp; 10Hrs<BR>
                                        <B>Warranty </B> &nbsp; 12months<BR>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingfour">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                            Common Features <i class="ti-plus"></i><i class="ti-minus"></i>
                                          </button>
                                      </h5>
                                  </div>
                                  <div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>The handle includes Fwd / Rev Buttons</B><BR>
                                        <B>Multispeed Selection Switch</B><BR>
                                        <B>Emergency Button</B><BR>
                                        <B>Battery Level Indicator</B><BR>
                                        <B>Least Maintenance</B><BR>
                                        <B>Less Operating Cost</B><BR>
                                        <B>4 Speed Operation</B><BR>
                                        <B>Noiseless</B><BR>
                                        <B>Zero Emissions</B><BR>
                                      </div>
                                  </div>
                              </div>

                          </div>

                        </div>
                        <div class="tab-pane fade" id="care" role="tabpanel" aria-labelledby="care-tab">
                            <div id="accordion6">
                              <div class="col-lg-12">
                                  <div class="product_slider">
                                      <div class="pr_image owl-carousel">
                                          <div class="item">
                                              <img src="img/reso/var4.png" alt="Tipper Trolley">
                                          </div>
                                          <div class="item">
                                              <img src="img/reso/var42.png" alt="Tipper Trolley">
                                          </div>
                                          <div class="item">
                                              <img src="img/reso/var43.png" alt="Tipper Trolley">
                                          </div>
                                          <div class="item">
                                              <img src="img/reso/var44.png" alt="Tipper Trolley">
                                          </div>
                                      </div>
                                  </div>
                              </div>

                              <div class="card">
                                  <div class="card-header" id="headingOne">
                                      <h5 class="mb-0">
                                      <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                      Exterior Features<i class="ti-plus"></i><i class="ti-minus"></i>
                                      </button>
                                      </h5>
                                  </div>

                                  <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Overall size(LxWxH) </B> &nbsp; 2150mm x 1300mm x 1000mm<BR>
                                        <B>Cargo box size </B> &nbsp; 1400mm x 1000mm x 350mm<BR>
                                        <B>Cargo box height from floor </B> &nbsp; 440mm<BR>
                                        <B>Frame construction </B> &nbsp; Steel<BR>
                                        <B>Color </B> &nbsp; Black & Yellow<BR>
                                        <B>Wheel diameter </B> &nbsp; 350mm<BR>
                                      </div>
                                  </div>
                              </div>

                              <div class="card">
                                  <div class="card-header" id="headingTwo">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                          Performance Stats<i class="ti-plus"></i><i class="ti-minus"></i>
                                  </button>
                                      </h5>
                                  </div>
                                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Loading capacity </B> &nbsp; 500kg<BR>
                                        <B>Nett weight </B> &nbsp; 175kg<BR>
                                        <B>Tipper inclination </B> &nbsp; 45°<BR>
                                        <B>Tipper operation </B> &nbsp; Hydraulic - Electric powered/ Manual<BR>
                                        <B>Turning radius </B> &nbsp; 1.2mt<BR>
                                        <B>Top speed </B> &nbsp; 10km/hr<BR>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingThree">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                              Battery Standards <i class="ti-plus"></i><i class="ti-minus"></i>
                                          </button>
                                      </h5>
                                  </div>
                                  <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>Motor BLDC </B> &nbsp; 900w<BR>
                                        <B>Battery </B> &nbsp; 4 x 12V, 42Ah<BR>
                                        <B>Charger </B> &nbsp; External<BR>
                                        <B>Rapid charging time </B> &nbsp; 3Hrs<BR>
                                        <B>Working time </B> &nbsp; 10Hrs<BR>
                                        <B>Warranty </B> &nbsp; 12months<BR>
                                      </div>
                                  </div>
                              </div>
                              <div class="card">
                                  <div class="card-header" id="headingfour">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                            Common Features <i class="ti-plus"></i><i class="ti-minus"></i>
                                          </button>
                                      </h5>
                                  </div>
                                  <div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordion">
                                      <div class="card-body">
                                        <B>The handle includes Fwd / Rev Buttons</B><BR>
                                        <B>Multispeed Selection Switch</B><BR>
                                        <B>Emergency Button</B><BR>
                                        <B>Battery Level Indicator</B><BR>
                                        <B>Least Maintenance</B><BR>
                                        <B>Less Operating Cost</B><BR>
                                        <B>4 Speed Operation</B><BR>
                                        <B>Noiseless</B><BR>
                                        <B>Zero Emissions</B><BR>
                                      </div>
                                  </div>
                              </div>
                              </div>
                        </div>
                        <div class="tab-pane fade" id="special" role="tabpanel" aria-labelledby="special-tab">

                            <div id="accordion">
                                <img class="img-fluid" src="img/reso/var5.png" alt="Special">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="mb-0">
                                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                          We provide customised solutions for material handling also.
                                        </button>
                                        </h5>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="mb-0">
                                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                          Automatic driverless guided trolleys are also available in all variants.
                                        </button>
                                        </h5>
                                    </div>
                                </div>

                            </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'foot.php';?>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/propper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="vendors/bootstrap-selector/js/bootstrap-select.min.js"></script>
    <script src="vendors/wow/wow.min.js"></script>
    <script src="vendors/sckroller/jquery.parallax-scroll.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
    <script src="vendors/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="vendors/isotope/isotope-min.js"></script>
    <script src="vendors/magnify-pop/jquery.magnific-popup.min.js"></script>
    <script src="vendors/scroll/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
</body>

</html>
